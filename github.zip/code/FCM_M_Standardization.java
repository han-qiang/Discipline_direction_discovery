﻿package test;

import java.text.NumberFormat;

import test.Reverse_test;


public class FCM_M_Standardization {
	
	
		public static void main(String[] args){
		System.out.println("FCM_Mahalanobis--Algorithm--陈杰" + "\n");
		//定义初始数据，并将其归一化
		double [][]X = new double[][]{{1,0,3},{3,0,6},{1,4,6},{2,4,9},{3,4,5}};  //测试数据		
		System.out.println("数据矩阵");
		//原始数据归一化矩阵
		int x = X.length;  //将数据坐标的个数定义为数据个数
		int y = X[0].length;		//数据维度				
		for (int i = 0; i < x; i++) {	  //输出原始数据矩阵
			for (int j = 0; j < y; j++) {
				System.out.print(X[i][j] + "\t");
			}
				System.out.println();
		}
		
		System.out.println();
		

		//计算标准化数据
				////////////////////////////////////////////////
				////////////////////////////////////////////////
		        //标准差公式：zij=（xij－xi）/si
				double X_average[] = new double[y];		//计算数据点的平均值 用一维数组average[y]保存		
				System.out.println("均值矩阵:");
				for (int i = 0; i < y; i++) {			 
					for (int j = 0; j < x; j++) {
						X_average[i] += X[j][i];
					}	
						X_average[i] = X_average[i] / x;
					System.out.print(X_average[i]+"\t");	//打印平均值
				}	System.out.println("\n");
				
				System.out.println("方差矩阵:");
				double variance[] = new double[y]; 
				double v_sum = 0;
				for (int i = 0; i < y; i++) {
					v_sum = 0;
					for (int j = 0; j < x; j++) {
						v_sum += Math.pow(X[j][i] - X_average[i], 2);			
					}	
					    variance[i] = Math.sqrt(v_sum / x);
						//System.out.print("v_sum" + v_sum+"\t");			    
				}		
				
				//输出方差矩阵
				//System.out.println("方差");
				for (int i = 0; i < y; i++) {
					System.out.print(variance[i] + "\t");
				}	System.out.println("\n");
					
				//标准差矩阵
				double Standardization[][] = new double[x][y];		
				for (int i = 0; i < x; i++) {
					for (int j = 0; j < y; j++) {
						Standardization[i][j] = (X[i][j] - X_average[j]) / variance[j] ;		//计算标准差
					}
				}
				
				//输出标准化矩阵
				System.out.println("标准化数据矩阵:");
				for (int i = 0; i < x; i++) {
					for (int j = 0; j < y; j++) {
						System.out.print(Standardization[i][j] + "\t");
					}	System.out.println();
				}

				////////////////////////////////////////////////
				////////////////////////////////////////////////
		
		//给定初始聚类中心	
		double [][] V = new double[][]{{-10,4},{7,4}};				//测试数据
		
		System.out.println();
 		System.out.println("初始聚类中心");  //输出初始聚类中心
		for (int i = 0; i < V.length; i++) {
			for (int j = 0; j < V[0].length; j++) {				
				System.out.print(V[i][j] + "\t");
			}
				System.out.println();
		}		System.out.println();
		
		
		/////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////
		//计算协方差矩阵
		//定义协方差矩阵
		double XFC[][] = new double [y][y];		
		double average[] = new double[y];		//计算数据点的平均值 用一维数组average[y]保存
		//System.out.println("均值矩阵");
		for (int i = 0; i < y; i++) {			 
			for (int j = 0; j < x; j++) {
				average[i] += Standardization[j][i];
			}	
				average[i] =average[i] / x;
			//System.out.print(average[i]+"\t");	//打印平均值
		}	//System.out.println("\n");
		
		//计算协方差矩阵
		System.out.println("协方差矩阵:");
		double XFC_sum = 0;
		for (int i = 0; i < y; i++) {			
			for (int j = 0; j < y; j++) {			
				for (int k = 0; k < x; k++) {  //k代表第几个点 
					/*协方差公式:
					S(i,j)={[His1(i)-u(i)]*[His1(j)-u(j)]+[His2(i)-u(i)]*[His2(j)-u(j)]}
					*/							
							//XFC_sum = 0;
							XFC_sum += (Standardization[k][i] - average[i])*(Standardization[k][j] - average[j]);

							//System.out.println("XFC_sum"+XFC_sum); //输出XFC_sum					        			        
				}				
				XFC[i][j] = XFC_sum / (x-1);
				XFC_sum =0;		//将协方差中的每个点赋值给XFC[][]矩阵
			}				
		}
		
		for (int i = 0; i < y; i++) {		//输出协方差矩阵
			for (int j = 0; j < y; j++) {
				System.out.print(XFC[i][j]+"\t");		
			}	System.out.println();
		}
		System.out.println();
		
		/////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////
		//计算协方差矩阵的逆矩阵
		double XFC_inverse[][] = new double[y][y];
		FCM_M_Standardization nijuzhen = new FCM_M_Standardization ();
		XFC_inverse=nijuzhen.getReverseMartrix(XFC);
		
		/*System.out.println("协方差逆矩阵：");
		for (int i = 0; i < y; i++) {		//输出协方差矩阵的逆矩阵
			for (int j = 0; j < y; j++) {
				System.out.print(XFC_inverse[i][j]+"\t");		
			}	System.out.println();
		}
		System.out.println();*/
		
		/////////////////////////////////////////////////////////////
		/////////////////////////////////////////////////////////////
		System.out.println();
		
		
		//人工输入
		//确定加权指数
		double r = 1.5 ;
		//确定分类数量
		int c = V.length;
		//确定模糊精度
		double E = 0.000000000001;
		int iternum = 1000;
		
		
		//定义欧式距离矩阵
		double [][]D = new double[x][c];
		//定义隶属度矩阵
		double [][]A = new double[x][c];
		//定义隶属度暂存矩阵
		double [][]A_temp = new double[x][c];
		//定义中心暂存矩阵
		double [][]V_temp = new double[c][y];
		//禁用科学计数法
		NumberFormat nf = NumberFormat.getInstance();
		nf.setGroupingUsed(false);// 不用科学计数
		
		///////////////////////////////////////////
		/////////////////////////////////////////
		//开始迭代!!!
		double A_sum = 99999999;	//矩阵范数
		for (int z = 1; z < iternum + 1 ; z++) {
			//定义目标函数
			double J = 0;
			System.out.println("第" + z +"次迭代！");
			if (A_sum < E || z > iternum) {
				System.out.println("迭代结束，累死宝宝了!");
				break;
			}
			//暂存聚类中心矩阵 为矩阵范数做准备 
			for (int i = 0; i < c; i++) {
				for (int j = 0; j < y; j++) {
					V_temp[i][j] = V[i][j]; 
				}
			}
			//暂存隶属度矩阵 为矩阵范数做准备 
			/*for (int i = 0; i < x; i++) {
				for (int j = 0; j < y; j++) {
				//	A_temp[i][j] = A[i][j]; 
				}
			}*/
			
		///////////////////////////////////////
		///////////////////////////////////////	马氏距离！	
		//样本到聚类中心的距离
			//计算马氏距离
			//马氏距离公式： D=sqrt{[His1-His2] * S^(-1) * [(His1-His2)的转置列向量]}
			System.out.println("马氏距离矩阵:");
			double M_distance[][] = new double[x][c];   //用一个二维数组保存样本点到各距离中心的马氏距离
		//	double D[] = new double[x*y*c];		
			double substract[] = new double[x*y*c];			//定义样本坐标与聚类中心的差值为 substract
			double temp[] = new double[x*y*c];
			double substract_X[][] = new double[x * c][y];
			int zz = 0;
			for (int i = 0; i < x; i++) {
				for (int j = 0; j < c; j++) {														
					for (int j2 = 0; j2 < y; j2++) {				
						substract[zz] = Standardization[i][j2]-V[j][j2];  	 //计算substract	 即样本坐标与聚类中心的差值	
						temp[zz] = substract[zz];				 //将数组substract的值赋给temp数组 
						zz = zz + 1;
					}			
				}
			}		
			
			/*	
		    System.out.println("temp");
			for (int i = 0; i < temp.length; i++) {
				System.out.print(temp[i]+"\t");				//输出temp[]
			}	System.out.println();
			*/
			
			int cc = 0;
			for (int j2 = 0; j2 < x * c ; j2++) {
				for (int k = 0; k < y ; k++) {						
					substract_X[j2][k]= substract[cc];  //substract 保存在二维数组substract_X中
					cc += 1;
				}	
			}				
			
		/*	System.out.println("substract");
			for (int i = 0; i < x * c; i++) {
				for (int j = 0; j < y ; j++) {
					System.out.print(substract_X[i][j]+"\t");		//输出substract_X
				}   System.out.println();
			}		System.out.println();	
			*/
			
			double m = 0;
			int m_num = 0;
			double m_array[] = new double[x*y*c];
			for (int i = 0; i < c * x; i++) {
				for (int j = 0; j < y; j++) {				
					for (int k = 0; k < y; k++) {						
							m += substract_X[i][k] * XFC_inverse[k][j];     //将差值substract和协方差矩阵的逆矩阵对应相乘累加  		substract_X[x][c*y] * XFC[y][y]	
						//	System.out.print(m + "\t");
					}							 
						//	System.out.print(m + "\t");
							m_array[m_num] = m;						//将m存储在大小为x*y*c的一维数组m_array[]中
							m_num += 1;						
						    m = 0;	
				}
			}			
			//System.out.println();
			
		/*	System.out.println("m_array");
			for (int i = 0; i < m_array.length; i++) {
				System.out.print(m_array[i]+"\t");					//输出m_array[]
			}
				System.out.println();*/
			     
			/*
			System.out.println();
			System.out.println("cha");
			for (int i = 0; i < temp.length; i++) {
				System.out.print(temp[i]+"\t");				     	//输出temp[]
			} 				
			System.out.println();*/
			//////注意temp和m_array的对应关系！！！！！！！！！！！
			
								
			double distance[] = new double[x*c];				
		//将temp与m_array对应相乘累加再开根号   并按照x*c的距离矩阵M_distance保存	
			for (int j2 = 0; j2 < x*y*c; j2++) {
				temp[j2] = m_array[j2] * temp[j2];       //将temp与m_array对应相乘 并赋值给temp				
				//System.out.print(temp[j2] + "\t");			
			}			
			
			int dd = 0;
			for (int j = 0; j < x*y*c; j++) {			//将temp数组每y个进行累加，并赋值给distance数组												
				if (j % y == 0 && j != 0) {			
					dd += 1;	
				}  
				distance[dd] += temp[j]; 
			}																
			
			/*System.out.println();
			System.out.println("distance");
			for (int i = 0; i < x * c; i++) {
				System.out.print(distance[i]+"\t");     //输出distance矩阵
			}*/		
			 
			dd = 0;
			for (int i = 0; i < x; i++) {
				for (int j = 0; j < c; j++) {
				   
				M_distance[i][j] = Math.sqrt(distance[dd]);
				//		M_distance[i][j] = distance[dd];
					dd += 1;
				}
			}
			
			//System.out.println();
			for (int i = 0; i < x; i++) {
				for (int j = 0; j < c; j++) {
					System.out.print(M_distance[i][j]+"\t");	//输出马氏距离矩阵
				}	System.out.println();
			}
		
		///////////////////////////////////////////
		///////////////////////////////////////////	马氏距离结束！		
		
			
		//计算隶属度
		System.out.println("");
		System.out.println("隶属度矩阵:");
		
		for (int i = 0; i < x; i++) {
			for (int j = 0; j < c; j++) {
				double sum1 = 0;						
                for (int j_a = 0; j_a < c; j_a++) {
                	if (M_distance[i][j] == 0) {
                		M_distance[i][j] = 0.00000000000000000001;     //    0比0的不定型  会产生NaN问题
					}
                    sum1 += Math.pow((M_distance[i][j] / M_distance[i][j_a]),2/(r-1));               	
                }                          
                A[i][j] = 1/sum1; 
                A_temp[i][j] = A[i][j]; //将隶属度矩阵A[][]的值给暂存矩阵A
                System.out.print(1/sum1+"\t");                       
			}
				System.out.println();
		}
		///////////////////////////////////////////
		///////////////////////////////////////////	
		
		///////////////////////////////////////////	
			//计算聚类中心
			System.out.println("");		
			double u_r = 0;
			double sum_u_r = 0;
			double []fm=new double[c];
			for (int j = 0; j < c; j++) {	//计算分母
				sum_u_r = 0; 
				for (int j2 = 0; j2 < x; j2++) {
					u_r = Math.pow(A[j2][j], r);
					sum_u_r += u_r;									
				}
				fm[j] = sum_u_r;
			}
			
			//计算分子  (每一个隶属度的r次方与数据点的各坐标值坐标相乘 )
			double sum2 = 0;
			for (int j = 0; j < c; j++) {	//隶属度矩阵的列数（分类个数）
				for (int i = 0; i < y; i++) {	//数据矩阵的列数（维度）
					for (int j2 = 0; j2 < x; j2++) {	//数据矩阵的行数（点的个数）
							sum2 += Math.pow(A[j2][j], r) * Standardization[j2][i];							
					}
					V[j][i]=sum2/fm[j];   //把分子除以分母作为聚类中心的坐标值
					sum2=0;
				}										
			}		 
			
			
			System.out.println("聚类中心的坐标：");
			for (int i = 0; i <c; i++) {
				for (int j = 0; j < y; j++) {
					System.out.print(V[i][j]+"\t" );	
				}	
					System.out.println();	//输出聚类中心坐标
			}		
		///////////////////////////////////////////
		
			
		///////////////////////////////////////////
		///////////////////////////////////////////	
		//求解矩阵范数（迭代的终止条件之一）,判定是否中止迭代	
		double sum =0;
		//根据A求范数
		/*for (int i = 0; i <  x; i++) {
			for (int j = 0; j < c; j++) {	
			//	System.out.println(A_temp[i][j]+"A_temp");
			//	System.out.println(A[i][j]+"A");
			//	sum += Math.pow((A_temp[i][j]- A[i][j]) ,2); //计算矩阵范数_求隶属度矩阵和暂存矩阵的欧式距离
				sum += Math.pow((V_temp[i][j]- V[i][j]) ,2); //计算矩阵范数_求隶属度矩阵和暂存矩阵的欧式距离
				System.out.println("sum"+sum);
			}
		}*/
			//	A_sum = Math.sqrt(sum);
			//	System.out.println("矩阵范数=" + A_sum);
				System.out.println();	
		//根据A求范数结束
				
				
		//根据V求范数
				for (int i = 0; i <  c; i++) {
					for (int j = 0; j < y; j++) {						
						sum += Math.pow((V_temp[i][j]- V[i][j]) ,2); //计算矩阵范数_求隶属度矩阵和暂存矩阵的欧式距离
					//	System.out.println("sum"+"\t"+sum);
					//	System.out.println("V_temp"+V_temp[i][j]);
					//	System.out.println("V"+V[i][j]);
					}
				}
						A_sum = Math.sqrt(sum);
					//	NumberFormat A_sum = NumberFormat.getInstance();
					//	A_sum.setMaximumFractionDigits(20);
					//	System.out.println("矩阵范数=" + nf.format(A_sum));  //正常输出
						System.out.println("矩阵范数=" + A_sum);  //默认  科学计数法输出
						
		 //根据V求范数结束			
		///////////////////////////////////////////
		///////////////////////////////////////////
		
		//////////////////////////////////////////
		//计算目标函数			
		for (int i = 0; i < x; i++) {
			for (int k = 0; k < c; k++) {
				J += Math.pow(A[i][k], r) * Math.pow(M_distance[i][k],2);
					
			}		
		}
		System.out.println("目标函数:" + J);
		System.out.println();		
		
		//////////////////////////////////////////
		
		///////////////////////////////////////////
		///////////////////////////////////////////	
		
		//聚类结果  
		double max = 0;
		double group[] = new double[x];		
		int k ;
		int max_k;
		System.out.println("聚类结果:");
		for (int i = 0; i < x; i++) {				//找到隶属度矩阵中每行最大的值，记为max，同时将该值所在的行数（第几个样本点）保存在group数组中 
			 k = 0;
			 max_k = 0;
			 max = 0;
			for (k = 0; k < c; k++) {						
					if (max <= A[i][k]) {			
		 				max = A[i][k];
		 				max_k = k;
					}	
			}
			group[i]= max_k;	 //将max分配给group数组 k-1保证数组不会溢出
		}
		
		for (int o = 0; o < c; o++) {
			System.out.println("第"+(o+1)+"类:");
			for (int i = 0; i < group.length; i++) {
				if(group[i]==o)
				{
					System.out.print((i+1)+" ");
				}									
			}System.out.println();
		}
		
						
			 System.out.println("\n");
		
		///////////////////////////////////////////
		///////////////////////////////////////////
		
	}	//迭代结束！！！
	
 }		
		/*public static void nijuzhen(double[][] args) {
	        // TODO Auto-generated method stub
	        ReverseMartrix rm = new ReverseMartrix();
	        rm.getReverseMartrix(args);
		}*/
	     
	    public double[][] getReverseMartrix(double[][] data) {
	        double[][] newdata = new double[data.length][data[0].length];
	        double A = getMartrixResult(data);//计算n维行列式的值
	        System.out.println("行列式：");
	        System.out.println(A);
	        for(int i=0; i<data.length; i++) {
	            for(int j=0; j<data[0].length; j++) {
	                if((i+j)%2 == 0) {
	                    newdata[i][j] = getMartrixResult(getConfactor(data, i+1, j+1)) / A;//逆矩阵之前的转置操作
	                }else {
	                    newdata[i][j] = -getMartrixResult(getConfactor(data, i+1, j+1)) / A;
	                }
	                 
	            }
	        }
	        newdata = trans(newdata);//对矩阵进行转置操作，得到逆矩阵
	         
	        showMaxtrix(newdata);//输出逆矩阵
	        return newdata;
	    }
	    
	    
	    private void showMaxtrix(double[][] newdata) {
	    	System.out.println();
	    	System.out.println("协方差的逆矩阵：");
	        for(int i=0;i<newdata.length; i++) {
	            for(int j=0; j<newdata[0].length; j++) {
	                System.out.print(newdata[i][j]+ "   ");
	            }
	            System.out.println();
	        }
	    }
	     
	    private double[][] trans(double[][] newdata) {
	        // TODO Auto-generated method stub
	        double[][] newdata2 = new double[newdata[0].length][newdata.length];
	        for(int i=0; i<newdata.length; i++)
	            for(int j=0; j<newdata[0].length; j++) {
	                newdata2[j][i] = newdata[i][j];
	            }
	        return newdata2;
	    }
	 
	    /*
	     * 计算行列式的值
	     */
	    public double getMartrixResult(double[][] data) {
	        /*
	         * 二维矩阵计算
	         */
	        if(data.length == 2) {
	            return data[0][0]*data[1][1] - data[0][1]*data[1][0];
	        }
	        /*
	         * 二维以上的矩阵计算
	         */
	        double result = 0;
	        int num = data.length;
	        double[] nums = new double[num];
	        for(int i=0; i<data.length; i++) {
	            if(i%2 == 0) {
	                nums[i] = data[0][i] * getMartrixResult(getConfactor(data, 1, i+1));
	            }else {
	                nums[i] = -data[0][i] * getMartrixResult(getConfactor(data, 1, i+1));
	            }
	        }
	        for(int i=0; i<data.length; i++) {
	            result += nums[i];
	        }
	         
//	      System.out.println(result);
	        return result;
	    }
	     
	    /*
	     * 求(h,v)坐标的位置的余子式
	     */
	    public double[][] getConfactor(double[][] data, int h, int v) {
	        int H = data.length;
	        int V = data[0].length;
	        double[][] newdata = new double[H-1][V-1];
	        for(int i=0; i<newdata.length; i++) {
	            if(i < h-1) {
	                for(int j=0; j<newdata[i].length; j++) {
	                    if(j < v-1) {
	                        newdata[i][j] = data[i][j];
	                    }else {
	                        newdata[i][j] = data[i][j+1];
	                    }
	                }
	            }else {
	                for(int j=0; j<newdata[i].length; j++) {
	                    if(j < v-1) {
	                        newdata[i][j] = data[i+1][j];
	                    }else {
	                        newdata[i][j] = data[i+1][j+1];
	                    }
	                }
	            }
	        }
	         
//	      for(int i=0; i<newdata.length; i ++)
//	          for(int j=0; j<newdata[i].length; j++) {
//	              System.out.println(newdata[i][j]);
//	          }
	        return newdata;
	    }

}
