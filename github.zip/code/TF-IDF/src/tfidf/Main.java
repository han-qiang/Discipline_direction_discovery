package tfidf;

import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;



public class Main {

    public static void main(String[] args) throws IOException {

        Map<String, HashMap<String, Integer>> normal = ReadFiles.NormalTFOfAll("d:\\dir");
        for (String filename : normal.keySet()) {
            System.out.println("fileName " + filename);
            System.out.println("TF " + normal.get(filename).toString());
        }

        System.out.println("-----------------------------------------");

        Map<String, HashMap<String, Float>> notNarmal = ReadFiles.tfOfAll("d:\\dir");
        for (String filename : notNarmal.keySet()) {
            System.out.println("fileName " + filename);
            System.out.println("TF " + notNarmal.get(filename).toString());
        }

        System.out.println("----------------------------------------");

        Map<String, Float> idf = ReadFiles.idf("d:\\dir");
        for (String word : idf.keySet()) {
            System.out.println("keyword :" + word + " idf: " + idf.get(word));
        }

        System.out.println("-----------------------------------------");

        Map<String, HashMap<String, Float>> tfidf = ReadFiles.tfidf("d:\\dir");

        Map<String, List<Map.Entry<String, Float>>> result = new HashMap<>();

        Iterator<Entry<String, HashMap<String, Float>>> iterator = tfidf.entrySet().iterator();
        while(iterator.hasNext()) {
            HashMap<String, Float> hashMap = new HashMap<>();

            Entry<String, HashMap<String, Float>> entry = iterator.next();

            List<Map.Entry<String, Float>> arrayList = new ArrayList(entry.getValue().entrySet());

            Collections.sort(arrayList, new Comparator<Map.Entry<String, Float>>() {
                @Override
                public int compare(Map.Entry<String, Float> o1, Map.Entry<String, Float> o2){
                    if (o2.getValue()-o1.getValue() > 0) {
                        return 1;
                    }else if(o2.getValue()-o1.getValue() < 0){
                        return -1;
                    } else {
                        return 0;
                    }
                }
            });

            result.put(entry.getKey(), arrayList);
        }





        for (String filename : tfidf.keySet()) {
            System.out.print("fileName " + filename + ",");

            System.out.println(result.get(filename));
        }




//            for(Map.Entry<String, HashMap<String,Float>> entry : tfidf.entrySet()){
//
//
//
//
//                for(Map.Entry<String, Float> entries : entry.getValue().entrySet()){
//                    entries1 = new ArrayList<>(entry.getValue().entrySet());
//                    Collections.sort(entries1, new Comparator<Map.Entry<String, Float>>() {
//                        @Override
//                        public int compare(Map.Entry<String, Float> o1, Map.Entry<String, Float> o2){
//                            if (o2.getValue()-o1.getValue() > 0) {
//                                return 1;
//                            }else{
//                                return -1;
//                            }
//                        }
//                    });
//                }
//            }
//
//            for (Map.Entry<String, Float> entry : entries1) {
//                hashMap.put(entry.getKey(), entry.getValue());
//            }
//
//            tfidf.put(filename, hashMap);

    }
}